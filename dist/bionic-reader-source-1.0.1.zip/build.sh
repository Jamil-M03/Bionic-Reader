#!/usr/bin/env bash
#
# Reproduces an exact copy of the Bionic Reader add-on package.
#
# The extension's own source files (manifest.json, *.js, *.css, *.html, the
# SVG icon) are plain, hand-written source with NO build step — they are
# copied verbatim. The only third-party, machine-generated files are the two
# pdf.js library files, which are the official, unmodified, non-minified build
# of pdfjs-dist, fetched here directly from npm.
#
set -euo pipefail

PKG="pdfjs-dist"
VER="4.10.38"
OUT="dist"

command -v node >/dev/null || { echo "ERROR: Node.js is required (>= 18)."; exit 1; }
command -v npm  >/dev/null || { echo "ERROR: npm is required."; exit 1; }
command -v zip  >/dev/null || { echo "ERROR: the 'zip' utility is required."; exit 1; }

echo "Using Node $(node --version) / npm $(npm --version)"

# 1. Fetch the official, unmodified pdf.js library from npm.
echo "Fetching ${PKG}@${VER} from npm ..."
npm pack "${PKG}@${VER}" >/dev/null
tar -xzf "${PKG}-${VER}.tgz"

# 2. Assemble the extension directory.
rm -rf "${OUT}"
mkdir -p "${OUT}/pdfjs" "${OUT}/icons"

# Hand-written source — copied verbatim, no processing of any kind:
cp manifest.json content.js content.css background.js \
   popup.html popup.js popup.css \
   viewer.html viewer.js viewer.css "${OUT}/"
cp icons/icon-32.png icons/icon-48.png icons/icon-96.png icons/icon-128.png "${OUT}/icons/"

# Third-party library — copied verbatim from the npm package:
cp package/build/pdf.mjs        "${OUT}/pdfjs/pdf.mjs"
cp package/build/pdf.worker.mjs "${OUT}/pdfjs/pdf.worker.mjs"

# 3. Package it (manifest.json must be at the zip root).
rm -f bionic-reader.zip
( cd "${OUT}" && zip -r -q ../bionic-reader.zip . )

echo "Done."
echo "  Built extension : ./${OUT}/"
echo "  Packaged add-on : ./bionic-reader.zip"
echo ""
echo "The two files under ${OUT}/pdfjs/ are byte-identical to the files under"
echo "./pdfjs/ in this source package; both come from ${PKG}@${VER} on npm."
